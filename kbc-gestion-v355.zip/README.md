# KBC Gestion v3.5.5

Kavonni Business Consulting — Santo Domingo

## Nouveautés v3.5.5
- Paramètres > Synchronisation Cloud – Gist GitHub
  Export / Import PC ↔ téléphone en 2 clics
  Token stocké localement uniquement
- Personnaliser l'accueil : Titre / Sous-titre FR + ES
- Thème Jour/Nuit, Devise RD$ / €, FR / ES

## Synchro Gist – 1ère fois
1. github.com/settings/tokens → Generate new token (classic) → scope `gist` uniquement → copier le ghp_...
2. Dans KBC : Admin > Paramètres > Synchronisation Cloud → coller le Token → Exporter vers Gist
3. Le Gist ID se remplit tout seul, note-le
4. Sur le téléphone : ouvrir l'app, Paramètres → coller le même Token + Gist ID → Importer depuis Gist
5. Ensuite : Exporter sur le poste où tu travailles, Importer sur l'autre

Un backup JSON local est téléchargé automatiquement avant chaque import.

## Déploiement GitHub Pages
Upload index.html à la racine, Pages > main / root
